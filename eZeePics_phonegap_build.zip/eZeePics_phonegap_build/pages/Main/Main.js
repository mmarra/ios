dojo.declare("Main", wm.Page, {
	start: function() {
		
	},
	"preferredDevice": "tablet",

	_end: 0
});