Main.widgets = {
	layoutBox1: ["wm.Layout", {"autoScroll":false,"deviceSizes":null,"horizontalAlign":"left","verticalAlign":"top"}, {}, {
		iFrame1: ["wm.IFrame", {"deviceSizes":null,"deviceType":["tablet","phone"],"height":"100%","source":"http://www.ezeepics.com","width":"100%"}, {}]
	}]
}