dojo.declare("Main", wm.Page, {
start: function() {
},
"preferredDevice": "tablet",
_end: 0
});

Main.widgets = {
layoutBox1: ["wm.Layout", {"autoScroll":false,"deviceSizes":null,"horizontalAlign":"left","verticalAlign":"top"}, {}, {
iFrame1: ["wm.IFrame", {"deviceSizes":null,"deviceType":["tablet","phone"],"height":"100%","source":"http://www.ezeepics.com","width":"100%"}, {}]
}]
};

Main.prototype._cssText = '';
Main.prototype._htmlText = '';