File you need to know:
* app.css:  application CSS
* config.js: project settings that can be edited, including dojo settings. Generally for advanced users.
* index.html and login.html:  can be edited directly to customize, such as including meta, script and other tags. 
* types.js:  a studio managed file. Types can be added to the project with server (java) types or with wm.TypeDefinition.
* project.documentation.js: documentation for application owned components (docs entered by user using studio)
* project.js (i.e. myproject.js): declares your project class; contains any application owned component definitions and functions. Same as page js and widget.js for application owned components.
