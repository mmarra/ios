62x62: Windows Mobile icon and tile
64x64: WebOS Icon
